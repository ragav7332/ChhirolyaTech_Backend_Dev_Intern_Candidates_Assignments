API from backend url conatins
- Product details like men,women,kids clothing and products.
- Login
- registration
- search
- shop items

Backend Deployed Url placed on env file,By using end points of filtered item to fetching the data.

here Front-end Deployed Url : https://ecommerce-publishable.netlify.app/
