import './Checkout.css'

const Checkout = () => {
    return ( 
        <div className="">
        </div>
     );
}
 
export default Checkout;